﻿function ParseObjectLevel {
    param(
        [string[]]$lines,
        [ref]$currentLine=([ref]0),
        [string]$RegExCompare = '\A\s*((?<key>"[^"]+")|(?<brace>[\{\}]))\s*(?<lineValue>"[^"]*")?\Z'
    )

    $currTable = [ordered]@{}
    While ($currentLine.Value -lt $lines.count) {
        If ($lines[$currentLine.Value] -match $RegExCompare) {
            if ($matches.key) { $currKey = $matches.key }
            if ($matches.lineValue) { $currTable.$currKey = $matches.lineValue }
            elseif ($matches.brace -eq '{') {
                $currentLine.Value++
                $currTable.$currKey = ParseObjectLevel -lines $lines `
                    -currentLine $currentLine -RegExCompare $RegExCompare
            } elseif ($matches.brace -eq '}') {
                break
            }
        } 
        $currentLine.Value++
    }
    return $currTable
}


function SteamInstallGameLocation {
    param(
        [Parameter(Mandatory=$true)]
        $Id
    )
$SteamDirectory = $null
$SteamDirectory = (Get-Item HKCU:\Software\Valve\Steam -ErrorAction SilentlyContinue).GetValue("SteamPath")
if ($SteamDirectory -eq $null) {$null}
$myFile = "$SteamDirectory\steamapps\libraryfolders.vdf"
$myContent = Get-Content $myFile
$myObject = ParseObjectLevel -lines $myContent

$SteamPathGameLocation = $null
foreach ($table in $myObject["`"libraryfolders`""].Values)
    {
    if ($table.'"apps"'.Keys -match "$Id") {$SteamPathGameLocation = $table.'"path"'}
    }
if ($SteamPathGameLocation -ne $null)
    {
    $SteamPathGameLocation = $SteamPathGameLocation -replace "\\\\","\" -replace '"',''
    $CurrentManifest = "$SteamPathGameLocation\steamapps\appmanifest_$Id.acf"
    try
        {
        $myContent1 = Get-Content $CurrentManifest -ErrorAction Stop
        $myObject1 = ParseObjectLevel -lines $myContent1
        $GameFolderName = $myObject1["`"AppState`""]."`"installdir`""
        $GameFolderName = $GameFolderName -replace '"',''
        "$SteamPathGameLocation\SteamApps\common\$GameFolderName"
        }
    catch
        {
        "Steam appmanifest not found"
        }
    }
else
    {
    $null
    }
}

# Current Directory Game Files (Steam)
#$InstallLocation_Steam = Get-ItemPropertyValue "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 261550" -name "InstallLocation" -ErrorAction SilentlyContinue
#$DisplayName_Steam = Get-ItemPropertyValue "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 261550" -name "DisplayName" -ErrorAction SilentlyContinue
$InstallLocation_Steam = SteamInstallGameLocation -Id 261550
if ($InstallLocation_Steam -eq "Steam appmanifest not found")
    {
    cls
    "############################"
    "# MODULE UNBLOCK DDL v1.52 #"
    "############################"
    ""
    "Steam appmanifest not found."
    "Please restart Steam and re-launch this script."
    ""
    pause
    exit
    }

if ($InstallLocation_Steam -ne $null) {$DisplayName_Steam = Split-Path $InstallLocation_Steam -Leaf}

# Current Directory Game Files (GOG)
$InstallLocation_GOG = Get-ItemPropertyValue "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\1564781494_is1" -name "InstallLocation" -ErrorAction SilentlyContinue
$DisplayName_GOG = Get-ItemPropertyValue "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\1564781494_is1" -name "DisplayName" -ErrorAction SilentlyContinue

# ErrorMessage Reset
$ErrorMessage = $null

# Object Forms
Add-Type -AssemblyName System.Windows.Forms

# Check Admin Mode
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$ADMIN = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($ADMIN -eq "True")
    {
    # Game not found. Select directory
    if (-not(($DisplayName_Steam -eq "Mount & Blade II Bannerlord") -or ($DisplayName_GOG -eq "Mount & Blade II: Bannerlord"))) 
        {
        cls
        "############################"
        "# MODULE UNBLOCK DDL v1.52 #"
        "############################"
        ""
        "This script could not find the location of the game. Please select directory game."
        ""
        $browser = New-Object System.Windows.Forms.FolderBrowserDialog
        #$null = $browser.ShowDialog()

        # Create a new instance of the form
        $form = New-Object System.Windows.Forms.Form
        $form.TopMost = $true
        $form.Width = 300
        $form.Height = 150
        $form.StartPosition = 'CenterScreen'
        $form.Text = "Select a Folder"
        $form.Visible = $true # Show the form

        # Create a new instance of the FolderBrowserDialog
        $folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
        $folderBrowser.ShowNewFolderButton = $true
        $folderBrowser.Description = "Please select directory game."
        $folderBrowser.RootFolder = [Environment+SpecialFolder]::Desktop

        # Display the dialog with the form as its parent
        $result = $folderBrowser.ShowDialog($form)

        # Hide the form after the dialog is closed
        $form.Close()

        # Check if the user selected a folder
        if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
            # Get the selected folder path
            $path = $folderBrowser.SelectedPath
            #Write-Host "You selected: $selectedPath"
        }

        #$path = $browser.SelectedPath

        $Boolean_String_Empty_Path = [string]::IsNullOrWhitespace($path)
        if ($Boolean_String_Empty_Path -eq $True) 
            {
            exit
            }

        else
            {
            # Check .exe launch Game
            #if ((Get-ChildItem "$path\bin\Win64_Shipping_Client\TaleWorlds.MountAndBlade.Launcher.exe" -ErrorAction SilentlyContinue) -or (Get-ChildItem "$path\bin\Gaming.Desktop.x64_Shipping_Client\Launcher.Native.exe" -ErrorAction SilentlyContinue))
                #{
                $GAME_CUSTOM_ROOT_DETECT = $path
                #}
            }
        }

    # Check if directory Game Found
    if (($DisplayName_Steam -eq "Mount & Blade II Bannerlord") -or ($DisplayName_GOG -eq "Mount & Blade II: Bannerlord") -or ($GAME_CUSTOM_ROOT_DETECT -ne $null))
        {
        cls
        "############################"
        "# MODULE UNBLOCK DDL v1.52 #"
        "############################"
        ""
        "File being checked. Please wait..."      
        
        $AllFolders = @()
        if ($DisplayName_Steam -eq "Mount & Blade II Bannerlord") {$AllFolders += Get-ChildItem "$InstallLocation_Steam\Modules" -Directory -Recurse | Where-Object { (Get-ChildItem $_.FullName).Count -ge 1 }}
        if ($DisplayName_GOG -eq "Mount & Blade II: Bannerlord") {$AllFolders += Get-ChildItem "$InstallLocation_GOG\Modules" -Directory -Recurse | Where-Object { (Get-ChildItem $_.FullName).Count -ge 1 }}
        if ($GAME_CUSTOM_ROOT_DETECT -ne $null) 
            {
            $AllFolders = Get-ChildItem @(
                "$GAME_CUSTOM_ROOT_DETECT\Modules",
                "$GAME_CUSTOM_ROOT_DETECT\Content\Modules"
            ) -Directory -Recurse | Where-Object { (Get-ChildItem $_.FullName).Count -ge 1 }
            }

        $FilesBlocked = @()
        foreach ($Folder in $AllFolders)
            {
            $CurrentDirectory = $Folder.Fullname
            try
                {
                $FilesBlocked += @((Get-Item $CurrentDirectory\* -Stream zone* -ErrorAction Stop).FileName)
                }
            catch
                {
                $ErrorMessage += @($_.Exception.Message)
                }
            }

        $Boolean_String_Empty_FilesBlocked = [string]::IsNullOrWhitespace($FilesBlocked)
        if ($Boolean_String_Empty_FilesBlocked -eq $False)
            {
            try
                {
                foreach ($File in $FilesBlocked)
                    {
                    if ($File -match "[A-Z]")
                        {
                        Unblock-File $File
                        }
                    }
                }
            catch
                {
                $ErrorMessage += @($_.Exception.Message)
                }
            }

        else
            {
            cls
            "############################"
            "# MODULE UNBLOCK DDL v1.52 #"
            "############################"
            ""
            "No files currently locked. Everything ok"
            ""
            pause
            exit
            }

        if ($ErrorMessage -match "[A-Z]")
            {
            cls
            "############################"
            "# MODULE UNBLOCK DDL v1.52 #"
            "############################"
            ""
            "Impossible unblock this dll(s) file(s) :"
            $ErrorMessage
            ""
            pause
            exit
            }
        
        else
            {
            cls
            "############################"
            "# MODULE UNBLOCK DDL v1.52 #"
            "############################"
            ""
            "Scrit successfully unblocked the files below : "
            $FilesBlocked
            ""
            pause
            exit
            }

        }

    else
        {
        cls
        "############################"
        "# MODULE UNBLOCK DDL v1.52 #"
        "############################"
        ""
        "This script could not find the location of the game. Please verify that your game is installed correctly."
        ""
        pause
        exit
        }
    }
else
    {
    cls
    "############################"
    "# MODULE UNBLOCK DDL v1.52 #"
    "############################"
    ""
    "This script was not launched as an administrator. Please verify that your Windows account has administrator rights."
    ""
    pause
    exit
    }
